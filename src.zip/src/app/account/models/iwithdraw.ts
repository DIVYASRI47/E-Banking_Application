export interface Iwithdraw {
    "amount": number;
}
