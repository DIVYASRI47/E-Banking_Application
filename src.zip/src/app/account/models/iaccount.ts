export interface Iaccount {
    accountType:string;
    panCardNumber:string;
    aadhaarNumber:string;
    mobileNumber:string;
    userId:number;
    balance: number;
  
}
