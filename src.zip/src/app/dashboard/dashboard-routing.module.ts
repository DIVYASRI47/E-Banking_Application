import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard-page/dashboard/dashboard.component';

const routes: Routes = [
  {path:'', component: DashboardComponent},
  {path:'user-dashboard', loadChildren: ()=>
  import('./user-dashboard/user-dashboard.module').then((m) => m.UserDashboardModule)
},
  {
    path : 'admin-dasboard', loadChildren: ()=>
    import('./admin-dashboard/admin-dashboard.module').then((m) => m.AdminDashboardModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
