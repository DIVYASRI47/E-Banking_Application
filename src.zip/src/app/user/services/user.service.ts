import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Iregister } from '../models/iregister';
import { Ilogin } from '../models/ilogin';
import { Observable } from 'rxjs';
const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) {}
  endPoint: string = '/api/auth';

  registerUser(register: Iregister): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/signup',
      register,
      headerData
    );
  }

  loginUser(login: Ilogin): Observable<any> {
    return this.httpClient.post(this.endPoint + '/login', login, headerData);
  }
}
