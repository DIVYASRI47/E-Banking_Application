export interface Ilogin {
    username: string;
    password: string;
}
